import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
/*import com.mapr.demo.mqtt.simple.Publisher;
import com.mapr.demo.mqtt.simple.Subscriber;*/

class SimpleMqttCallBack implements MqttCallback {

	public void connectionLost(Throwable throwable) {
		System.out.println("Connection to MQTT broker lost!");
  	}

 	public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
    		System.out.println("Message received:\t"+ new String(mqttMessage.getPayload()) );
  	}

  	public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
  	
  	}
}

class Subscriber {

  	public static void main(String[] args) throws MqttException {
		String grupo="Grupo1";
	
	
	    	System.out.println("== START SUBSCRIBER ==");

		MqttClient client=new MqttClient("37.187.106.16", MqttClient.generateClientId()); //conexao ao broker do mosquitto local (endereço 37.187.106.16)
	    	client.setCallback( new SimpleMqttCallBack() );
	    	client.connect();

	    	client.subscribe("SACN/CameoFXBar/Mode29/"+grupo);
	}
}

class Publisher {


	public static void main(String[] args) throws MqttException {
		String grupo="Grupo1";
	  	String messageString = "Hello World from Java!";

		if (args.length == 2 ) {
			messageString = args[1];
		}


		System.out.println("== START PUBLISHER ==");


		MqttClient client = new MqttClient("37.187.106.16", MqttClient.generateClientId());
		client.connect();
		MqttMessage message = new MqttMessage();
		message.setPayload(messageString.getBytes());
		client.publish("SACN/CameoFXBar/Mode29/"+grupo, message);

		System.out.println("\tMessage '"+ messageString +"' to 'SACN/CameoFXBar/Mode29/'");

		client.disconnect();

		System.out.println("== END PUBLISHER ==");
	}
}

public class MqttApp1 {

	public static void main(String[] args) throws MqttException {

		if (args.length < 1) {
			throw new IllegalArgumentException("Must have either 'publisher' or 'subscriber' as argument");
	    	}
	    	switch (args[0]) {
	     		case "publisher":
			Publisher.main(args);
			break;
	      		case "subscriber":
			Subscriber.main(args);
			break;
	      	default:
			throw new IllegalArgumentException("Don't know how to do " + args[0]);
	    	}
	}
}
